from django.apps import AppConfig


class DefaultAppConfig(AppConfig):
    name = "unfold.contrib.filters"
    label = "unfold_filters"
