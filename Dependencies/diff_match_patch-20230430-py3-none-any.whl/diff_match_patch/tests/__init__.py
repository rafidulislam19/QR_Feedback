from .diff_match_patch_test import DiffTest, MatchTest, PatchTest
