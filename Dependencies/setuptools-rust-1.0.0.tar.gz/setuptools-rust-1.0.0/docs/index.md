```{eval-rst}
.. toctree::
   :maxdepth: 2
   :hidden:

   README.md
   building_wheels
   reference
```

```{include} ../README.md
```
