API Reference
=============

.. py:module:: setuptools_rust

.. autoclass:: RustExtension
.. autoclass:: Binding
.. autoclass:: Strip
